<?php echo e($slot); ?>

<?php /**PATH D:\Studying\Laravel\www\devit-server\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>